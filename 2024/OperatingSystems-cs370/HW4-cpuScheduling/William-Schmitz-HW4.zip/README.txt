CPU scheduling algorithms

Implement:
First Come First Serve
Priority with preemption
Round Robin

to generate a Gantt chart to evaluate measures of effectiveness.