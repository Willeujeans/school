#ifndef PRIMES_H
#define PRIMES_H

int random_in_range(int lower_bound, int upper_bound);
int get_prime_count(int *array, int arraySize);
float get_running_ratio();

#endif
