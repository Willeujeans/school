package src;

public class MessageBuffer {
    private Message[] buffer;
    private int head;
    private int tail;
    private int count;
    private int bufferCapacity;

    public MessageBuffer(int size) {
        this.bufferCapacity = size;
        this.buffer = new Message[size];
        this.head = 0;
        this.tail = 0;
        this.count = 0;
    }

    public synchronized void emplaceMessage(Message message) throws InterruptedException {
        while (isFull()) {
            wait();
        }
        buffer[tail] = message;
        tail++;
        if (tail == bufferCapacity) {
            tail = 0;
        }
        count++;
        notifyAll();
    }

    public synchronized Message pollMessage() throws InterruptedException {
        while (isEmpty()) {
            wait();
        }
        Message message = buffer[head];
        head++;
        if (head == bufferCapacity) {
            head = 0;
        }
        count--;
        notifyAll();
        return message;
    }

    public synchronized boolean isEmpty() {
        return count == 0;
    }

    public synchronized boolean isFull() {
        return count == bufferCapacity;
    }
}
