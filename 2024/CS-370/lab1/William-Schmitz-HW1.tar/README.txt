Driver.c
    main():
        serves as the 'entry point' for the program

Primes.c
    random_in_range(min, max):
        will provide a number between two given numbers

    is_prime(number):
        will return true or false depending on if the provided number is or is not a prime

    get_prime_count():
        will interate through an array and check each element with is_prime()

    get_running_ratio():
        this method combines all previous methods to populate an array with random numbers, then will execute get_prime_count upon that array